package com.xxl.mq.client.message;

/**
 * @author xuxueli 2018-11-17 21:51:14
 */
public enum XxlMqMessageStatus {
    NEW,
    RUNNING,
    SUCCESS,
    FAIL;
}