package com.xxl.mq.sample.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author xuxueli 2018-11-17 17:21:44
 */
@SpringBootApplication
public class XxlMqSampleApplication {

	public static void main(String[] args) {
        SpringApplication.run(XxlMqSampleApplication.class, args);
	}

}


